package iss.java.mail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import com.sun.mail.imap.IMAPFolder;
import com.sun.mail.imap.IMAPStore;

import java.util.Properties;

public class Mailservice2014302580023 implements IMailService {
    /**
     * �����ʼ���props�ļ�
     */
    private final transient Properties props = System.getProperties();
    /**
     * �ʼ���������¼��֤
     */
    private transient MailAut2014302580023 authenticator;

    /**
     * ����session
     */
    private transient Session session;
    
    /**
     * �����ʼ���props�ļ�
     */

    /**
     * �ʼ���������¼��֤
     */
    private transient MailAut2014302580023 authenticator1;

    /**
     * ����session
     */
    private transient Session session1;
    
    private IMAPFolder folder= null;
    private IMAPStore store=null;
    

	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
        // ��ʼ��props
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.139.com");
        // ��֤
        authenticator = new MailAut2014302580023("15827467372@163.com", "t19980429");
        // ����session
        session = Session.getInstance(props, authenticator);
    
	}

	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO Auto-generated method stub
        // ����mime�����ʼ�
        final MimeMessage message = new MimeMessage(session);
        // ���÷�����
        message.setFrom(new InternetAddress(authenticator.getUsername()));
        // �����ռ���
        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
        // ��������
        message.setSubject(subject);
        // �����ʼ�����
        message.setContent(content.toString(), "text/html;charset=utf-8");
        // ����
        Transport.send(message);
	}

	public boolean listen() throws MessagingException {
		final Properties props1=System.getProperties();
		props1.put("mail.store.protocol", "pop3");
        props1.put("mail.pop3.host", "pop3.139.com");
        // ��֤
        authenticator1 = new MailAut2014302580023("15827467372@163.com", "t19980429");
        // ����session
        session1 = Session.getInstance(props1,authenticator1);
        int total= 0;
        Store store = session1.getStore();
        store.connect();
        Folder folder = store.getFolder("inbox");
        // ʹ��ֻ����ʽ���ռ��� 
        folder.open(Folder.READ_ONLY);
        //��ȡ���ʼ���
        total = folder.getMessageCount();
        folder.close(false);
        store.close();
        if(total!=0)
        	return true;
		// TODO Auto-generated method stub
		return false;
	}

	public String getReplyMessageContent(String subject)
			throws MessagingException, IOException {
		 Store store = session.getStore();
         store.connect();
  String content = null;
         // ��������ڵ��ʼ���Folder������"ֻ��"��
         Folder folder = store.getFolder("inbox");
         folder.open(Folder.READ_ONLY);
        Message[] messages = folder.getMessages();  
        for (int i = 0; i < messages.length; i++) {    
            if(messages[i].getSubject().contains(subject))
            	content=messages[i].getContent().toString();
        }
//		// TODO Auto-generated method stub
        folder.close(false);
        store.close();
		return content;

	}
}
