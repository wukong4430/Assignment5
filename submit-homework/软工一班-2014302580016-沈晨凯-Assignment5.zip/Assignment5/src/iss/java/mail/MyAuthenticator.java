package iss.java.mail;

import java.util.StringTokenizer;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.swing.JOptionPane;

public class MyAuthenticator extends Authenticator{
	
	String username, password;
	String result = "";
	public MyAuthenticator() {
         JOptionPane.showMessageDialog(null, "请确认输入163邮箱账号密码"); 
          result = JOptionPane.showInputDialog(
		      "Enter 'username,password'(*@163.com)");	//提示输入用户名以及密码   （用户名为163邮箱）
    }
	
	 public PasswordAuthentication getPasswordAuthentication() {
		    
		
		   				
		    StringTokenizer st = new StringTokenizer(result, ",");
		    username = st.nextToken();
		    password = st.nextToken();
		    return new PasswordAuthentication(username, password);
		  }
	 
	 public  String getName()
	 {
		 return username;
	 }
}